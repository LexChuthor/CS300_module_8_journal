//============================================================================
// Name        : Project2.cpp
// Author      : Patrick Chu
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Project 2
//============================================================================

#include <algorithm>
#include <iostream>
#include <time.h>
#include <iterator>
#include "CSVparser.hpp"

using namespace std;


//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Course {
    string courseNum; // unique identifier
    string courseName;
    vector<string> preReqs;
    Course() {
        courseNum = "";
        courseName = "";
    }
};

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the course information to the console (std::out)
 *
 * @param Course struct containing the course info
 */
void printCourse(Course& aCourse) {
    //if there are pre-requisite classes
    if (aCourse.preReqs.size() > 0) {
        cout << aCourse.courseNum << ": " << aCourse.courseName << " | Pre-Requistites: ";
        for (int i = 0; i < aCourse.preReqs.size() - 1; i++) {
            cout << aCourse.preReqs.at(i) << ", ";
        }
        cout << aCourse.preReqs.at(aCourse.preReqs.size() - 1) << endl;
    }
    else {
        cout << aCourse.courseNum << ": " << aCourse.courseName << endl;
    }
    return;
}

Course searchCourse(vector<Course>& courses, string courseNum) {
    Course course;
    //loop through course vector for matching course, then return that course
    for (int i = 0; i < courses.size(); i++) {
        if (courses.at(i).courseNum == courseNum) {
            return courses.at(i);
        }
    }
    return course;
}

void printSchedule(vector<Course>& courses) {
    //for every course in vector, print each course
    for (int i = 0; i < courses.size(); i++) {
        printCourse(courses.at(i));
    }
}

void printAlphaNumeric(vector<Course>& courses) {
    //for every course in vector, print each course
    list<string> coursenames;
    for (int i = 0; i < courses.size(); i++) {
        coursenames.push_back(courses.at(i).courseName);
    }
    coursenames.sort();
    for (auto course : coursenames) {
        cout << course << endl;
    }
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
vector<Course> loadCourses(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    // Define a vector data structure to hold a collection of courses.
    vector<Course> courses;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of courses
            Course aCourse;
            //if pre-requisites exist, load coursename and coursenum into course object
            if (file[i].size() > 2) {
                aCourse.courseName = file[i][1];
                aCourse.courseNum = file[i][0];
                //then for each pre-requisite, push into preReq vector
                for (int j = 2; j < file[i].size(); j++) {
                    aCourse.preReqs.push_back(file[i][j]);
                }
            }
            else {
                //push coursename and coursenum into course object
                aCourse.courseName = file[i][1];
                aCourse.courseNum = file[i][0];
            }
            // push this Course to the end
            courses.push_back(aCourse);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
    return courses;
}




/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    default:
        csvPath = "Courses.csv";
    }

    // Define a vector to hold all the bids
    vector<Course> courses;


    int choice = 0;
    string courseNum;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Print Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:


            // Complete the method call to load the courses
            courses = loadCourses(csvPath);

            cout << courses.size() << " courses read" << endl;

            break;

        case 2:
            // Loop and display the courses read
            printAlphaNumeric(courses);

            break;

        case 3:
            cout << "What course do you want to know about?" << endl;
            cin >> courseNum;

            Course searched = searchCourse(courses, courseNum);
            if (searched.courseNum != "") {
                printCourse(searched);
            }
            else {
                cout << "No matching courses found" << endl;
            }

            break;

        }
    }

    cout << "Good bye." << endl;

    return 0;
}
